<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {
    public function index()
    {
        $this->load->model("Mahasiswa_model", "mhs1");
        $this->mhs1->id=1;
        $this->mhs1->nim='010001';
        $this->mhs1->nama='Arzeno Akmal';
        $this->mhs1->gender='L';
        $this->mhs1->ipk=3.70;

        $this->load->model("Mahasiswa_model", "mhs2");
        $this->mhs2->id=2;
        $this->mhs2->nim='010002';
        $this->mhs2->nama='Haikal Hasan';
        $this->mhs2->gender='L';
        $this->mhs2->ipk=3.35;

        $this->load->model("Mahasiswa_model", "mhs3");
        $this->mhs3->id=3;
        $this->mhs3->nim='010003';
        $this->mhs3->nama='Jevan Ramadhan';
        $this->mhs3->gender='L';
        $this->mhs3->ipk=3.50;

        $this->load->model("Mahasiswa_model", "mhs4");
        $this->mhs4->id=4;
        $this->mhs4->nim='010004';
        $this->mhs4->nama='Nabilah Khariyyah';
        $this->mhs4->gender='P';
        $this->mhs4->ipk=3.95;

        $this->load->model("Mahasiswa_model", "mhs5");
        $this->mhs5->id=5;
        $this->mhs5->nim='010005';
        $this->mhs5->nama='Ridho Adhi';
        $this->mhs5->gender='L';
        $this->mhs5->ipk=3.83;

        $list_mhs = [$this->mhs1, $this->mhs2, $this->mhs3, $this->mhs4, $this->mhs5];
        
        $data['data_mhs'] = $list_mhs;
        $this->load->view('Mahasiswa/index', $data);
    }
}
?>