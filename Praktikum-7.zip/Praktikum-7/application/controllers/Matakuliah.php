<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {
    public function index()
    {
        $this->load->model('MataKuliah_model', 'matkul1');
        $this->matkul1->id=1;
        $this->matkul1->nama='Basis Data I';
        $this->matkul1->sks='4';
        $this->matkul1->kode='001';

        $this->load->model('MataKuliah_model', 'matkul2');
        $this->matkul2->id=2;
        $this->matkul2->nama='Dasar-Dasar Pemrograman';
        $this->matkul2->sks='3';
        $this->matkul2->kode='002';

        $this->load->model('MataKuliah_model', 'matkul3');
        $this->matkul3->id=3;
        $this->matkul3->nama='Jaringan Komputer';
        $this->matkul3->sks='3';
        $this->matkul3->kode='003';

        $this->load->model('MataKuliah_model', 'matkul4');
        $this->matkul4->id=4;
        $this->matkul4->nama='Pemrograman Web';
        $this->matkul4->sks='3';
        $this->matkul4->kode='004';

        $list_matkul = [$this->matkul1, $this->matkul2, $this->matkul3, $this->matkul4];
        
        $data2['data_matkul'] = $list_matkul;
        $this->load->view('Matakuliah/index', $data2);

    }
}

?>