<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Daftar Mahasiswa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        .body{
            margin-left:80px;
            margin-right:80px;
        }
        table{
            text-align:center;
        }
        th{
            text-align:center;
        }
        h1{
            margin:40px;
            text-align:center;
        }
    </style>
  </head>

  <body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
            <a class="navbar-brand" href="#">Pemrograman Web 2</a>
            </div>
            <ul class="nav navbar-nav">
            <li class="active"><a href="mahasiswa">Mahasiswa</a></li>
            <li><a href="dosen">Dosen</a></li>
            <li><a href="matakuliah">Mata Kuliah</a></li>
            </ul>
            <form class="navbar-form navbar-right" action="/action_page.php">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search" name="search">
                <div class="input-group-btn">
                <button class="btn btn-default" type="submit">
                    <i class="glyphicon glyphicon-search"></i>
                </button>
                </div>
            </div>
            </form>
        </div>
    </nav>

    </br>
    <h1>Daftar Mahasiswa</h1>
    <div class="container-fluid">
        <div class="body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                    <th scope="col">No</th>
                    <th scope="col">NIM</th>
                    <th scope="col">Nama Lengkap</th>
                    <th scope="col">Gender</th>
                    <th scope="col">IPK</th>
                    <th scope="col">Predikat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $nomor = 1;
                        foreach($data_mhs as $mhs){
                    ?>

                    <tr>
                        <td><?= $mhs->id ?></td>
                        <td><?= $mhs->nim ?></td>
                        <td><?= $mhs->nama ?></td>
                        <td><?= $mhs->gender ?></td>
                        <td><?= $mhs->ipk ?></td>
                        <td><?= $mhs->predikat() ?></td>
                    </tr>
                    
                    <?php
                        $nomor++;
                        }
                    ?>
                </tbody>
            </table>
        </div>
        </br></br>
    <footer class="main-footer">
        <div class="float-left d-none d-sm-block">
        <p align="right">Created by <a href="http://nurulfikri.ac.id">Pusinfo NF &copy;2017</a></p>
        </div>
    </footer>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>


    