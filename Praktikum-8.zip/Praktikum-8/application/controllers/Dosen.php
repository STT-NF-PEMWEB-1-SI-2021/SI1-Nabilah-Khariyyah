<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function index(){
        $this->load->model('Dosen_model', 'dsn1');
        $this->dsn1->id=1;
        $this->dsn1->nama='Dr. Ananda Reza, M.T, M.M.';
        $this->dsn1->nidn='0021086308';
        $this->dsn1->pendidikan='S3 Teknik Mesin';

        $this->load->model('Dosen_model', 'dsn2');
        $this->dsn2->id=2;
        $this->dsn2->nama='Erva Soraya, S.T., M.Kom';
        $this->dsn2->nidn='0012308922';
        $this->dsn2->pendidikan='S2 Ilmu Komputer';

        $this->load->model('Dosen_model', 'dsn3');
        $this->dsn3->id=3;
        $this->dsn3->nama='Joko Triatmojo, S.Si, M.Kom';
        $this->dsn3->nidn='0058099321';
        $this->dsn3->pendidikan='S2 Ilmu Komputer';

        $this->load->model('Dosen_model', 'dsn4');
        $this->dsn4->id=4;
        $this->dsn4->nama='Rachmawati Chairunnisa, S.E, M.Si';
        $this->dsn4->nidn='0048229360';
        $this->dsn4->pendidikan='S2 Sains';

        $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3, $this->dsn4];
        $data1['data_dsn'] = $list_dsn;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('Dosen/index', $data1);
        $this->load->view('layout/footer');
    }
    public function create(){
        $data['judul'] = 'Form Kelola Dosen';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/create', $data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model('Dosen_model', 'dsn1');

        $this->dsn1->nama = $this->input->post('nama');
        $this->dsn1->nidn = $this->input->post('nidn');
        $this->dsn1->pendidikan = $this->input->post('pendidikan');

        $data['dsn1'] = $this->dsn1;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('Dosen/view', $data);
        $this->load->view('layout/footer');

    }
}

?>