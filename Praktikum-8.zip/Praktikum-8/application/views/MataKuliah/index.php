<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Daftar Mata Kuliah</title>
    <link rel="stylesheet" href="<?php echo base_url('https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css')?>">
    <style>
        .content{
        margin-left:250px
        }
        table{
            text-align:center;
        }
        th{
            text-align:center;
        }
        h1{
            margin:40px;
            text-align:center;
        }
    </style>
  </head>

  <body>
    <section class="content">
        </br>
        <h1>Daftar Mata Kuliah</h1>
        <div class="container-fluid">
            <div class="body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                        <th scope="col">No</th>
                        <th scope="col">Mata Kuliah</th>
                        <th scope="col">SKS</th>
                        <th scope="col">Kode Mata Kuliah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $nomor = 1;
                            foreach($data_matkul as $matkul){
                        ?>

                        <tr>
                            <td><?= $matkul->id ?></td>
                            <td><?= $matkul->nama ?></td>
                            <td><?= $matkul->sks ?></td>
                            <td><?= $matkul->kode ?></td>
                        </tr>
                        
                        <?php
                            $nomor++;
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            </br></br></br></br>
        </div>
    </section>
    
    <script src="<?php echo base_url('https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous')?>"></script>
    <script src="<?php echo base_url('https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous')?>"></script>
    <script src="<?php echo base_url('https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous')?>"></script>
  </body>
</html>


    